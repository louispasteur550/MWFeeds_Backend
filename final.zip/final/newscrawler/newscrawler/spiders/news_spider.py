import scrapy
from ..items import NewscrawlerItem
from news.models import Headline
from newscrawler.spiders import news_spider
from newscrawler import pipelines

from datetime import datetime

# datetime object containing current date and time
now = datetime.now()
 
# print("now =", now)

# dd/mm/YY H:M:S
dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
# print("date and time =", dt_string)

class NewsSpider(scrapy.Spider):
	name = 'news'
	sent_url = ""
	# start_urls=[
	# 	'https://timesofindia.indiatimes.com/?from=mdr'
	# ]
	class_name = ""

	def __init__(self, start_url = None, class_name = None, *args, **kwargs):
		super(NewsSpider, self).__init__(*args, **kwargs)
		self.start_url = start_url
		self.start_urls = [self.start_url]
		self.class_name = class_name
		NewsSpider.sent_url = self.start_url
		# News.class_selector = args
		NewsSpider.class_name = self.class_name

	def parse(self, response):

		div_all_news =  response.css(NewsSpider.class_name)
		i=0
		for some in div_all_news:
			items = NewscrawlerItem()
			title =  some.css("::text").get()
			# title = title[5:]
			# title = title[:-3]
			link = some.css("a::attr(href)").get()
			img = some.css("img::attr(src)").get()
			i+=1
			title1 = title.split(" ")
			title1 = title1[0] + " " + title1[1]
			items['title'] = title
			items['description'] = title
			items['image'] = img
			items['url'] = link
			items['source'] = NewsSpider.sent_url
			items['date_time'] = dt_string
			yield items
			#if i==12:
			#	break

#app > div > div.contentwrapper.clearfix > div > div.BUoQz > div.f54wt > div.xKVXg > a:nth-child(1)
#app > div > div.contentwrapper.clearfix > div > div.BUoQz > div.f54wt > div.xKVXg > a > span

class TechSpider(scrapy.Spider):
	name = 'technews'
	start_urls=[
		'https://www.theverge.com/tech'
	]

	def parse(self, response):

		
		div_all_news =  response.xpath("//div[@class='c-compact-river']/div/div")
		i=0
		for some in div_all_news:
			items = NewscrawlerItem()
			title =  some.xpath("//div/h2/a/text()")[i].extract()
			link = some.xpath("//div/h2/a/@href")[i].extract()
			s = some.xpath("//a/div/noscript")[i].extract()
			l = s.split('"')
			img = l[3]
			i+=1
			l=[]
			items['title'] = title
			items['image'] = img
			items['url'] = link
			items['source'] = 'The Verge'
			yield items
			if i==12:
				break


class TOISpider(scrapy.Spider):
	name = 'TOI'
	start_urls=[
		'https://timesofindia.indiatimes.com/?from=mdr'
	]

	def parse(self, response):

		
		div_all_news =  response.xpath("//div[@class='undefined grid_wrapper']/div/div")
		i=0
		for some in div_all_news:
			items = NewscrawlerItem()
			title =  some.xpath("//div/div/figure/a/text()")[i].extract()
			link = some.xpath("//div/div/figure/a/@href")[i].extract()
			s = some.xpath("//a/div/noscript")[i].extract()
			l = s.split('"')
			img = l[3]
			i+=1
			l=[]
			items['title'] = title
			items['image'] = img
			items['url'] = link
			items['source'] = 'Times of India'
			yield items
			# if i==12:
			# 	break


