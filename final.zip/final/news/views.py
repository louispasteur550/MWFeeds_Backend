import requests
import time
from django.shortcuts import render, redirect
from uuid import uuid4
from django.http import JsonResponse, HttpResponse
from django.views.decorators.http import require_POST, require_http_methods
from django.views.decorators.csrf import csrf_exempt
from scrapyd_api import ScrapydAPI
from news.models import Headline,EHeadline,SHeadline,PHeadline,LHeadline,ENHeadline, SaveUrl
from django.contrib.auth.decorators import login_required
from django.views.generic import ListView
from django.conf import settings as django_settings

#for scrapy
import os
import sys

path = django_settings.BASE_DIR
sys.path.append(path + "/newscrawler")
sys.path.append(path + "/economycrawler")
sys.path.append(path + "/sportscrawler")
sys.path.append(path + "/politicscrawler")
sys.path.append(path + "/lifestylecrawler")
sys.path.append(path + "/entertainmentcrawler")
sys.path.append(path + "/getnews")


# sys.path.append("C:/Users/admin/Desktop/DJANGO/Practice_Django/News_Aggregator/newscrawler")
# sys.path.append("C:/Users/admin/Desktop/DJANGO/Practice_Django/News_Aggregator/economycrawler")
# sys.path.append("C:/Users/admin/Desktop/DJANGO/Practice_Django/News_Aggregator/sportscrawler")
# sys.path.append("C:/Users/admin/Desktop/DJANGO/Practice_Django/News_Aggregator/politicscrawler")
# sys.path.append("C:/Users/admin/Desktop/DJANGO/Practice_Django/News_Aggregator/lifestylecrawler")
# sys.path.append("C:/Users/admin/Desktop/DJANGO/Practice_Django/News_Aggregator/entertainmentcrawler")
# import autoscraper
from newscrawler.spiders import news_spider
from economycrawler.spiders import economy_spider
from sportscrawler.spiders import sports_spider
from politicscrawler.spiders import politics_spider
from lifestylecrawler.spiders import lifestyle_spider
from entertainmentcrawler.spiders import entertainment_spider
# from autoscraper.spiders import auto_crawl
from newscrawler.pipelines import NewscrawlerPipeline
# from autoscraper.pipelines import AutoscraperPipeline
from scrapy import signals
from twisted.internet import reactor
from scrapy.crawler import Crawler,CrawlerRunner, CrawlerProcess
from scrapy.settings import Settings
from scrapy.utils.project import get_project_settings
from newscrawler import settings as my_settings
from economycrawler import settings as economy_settings
from sportscrawler import settings as sports_settings
from politicscrawler import settings as politics_settings
from lifestylecrawler import settings as lifestyle_settings
from entertainmentcrawler import settings as entertainment_settings 
# from autoscraper import settings as autoscraper_settings
from scrapy.utils.log import configure_logging
from crochet import setup



#scrapyd = ScrapydAPI('http://localhost:6800')

def home1(request):
    return render(request, "news/starter.html")
'''
@login_required
def news_list(request):
    headlines = Headline.objects.all()[::-1]
    context ={
            'object_list' : headlines,
    }
    return render(request, "news/home.html", context)
'''

class NewsListView(ListView):
    model = Headline
    template_name = 'news/home.html'
    paginate_by = 5
'''
@login_required
def economy_news_list(request):
    headlines = EHeadline.objects.all()[::-1]
    context ={
            'object_list' : headlines,
    }
    return render(request, "news/economy_home.html", context)
'''

class EconomyListView(ListView):
    model = EHeadline
    template_name = 'news/economy_home.html'
    paginate_by = 5
'''
@login_required
def sports_news_list(request):
    headlines = SHeadline.objects.all()[::-1]
    context ={
            'object_list' : headlines,
    }
    return render(request, "news/sports_home.html", context)
'''
class SportsListView(ListView):
    model = SHeadline
    template_name = 'news/sports_home.html'
    paginate_by = 5


class PoliticsListView(ListView):
    model = PHeadline
    template_name = 'news/politics_home.html'
    paginate_by = 5

class LifestyleListView(ListView):
    model = LHeadline
    template_name = 'news/lifestyle_home.html'
    paginate_by = 5

class EntertainmentListView(ListView):
    model = ENHeadline
    template_name = 'news/entertainment_home.html'
    paginate_by = 5


@login_required
def menu_list(request):
    return render(request, "news/topics_list.html")


@csrf_exempt
@require_http_methods(['POST', 'GET'])
def scrape(request):
    Headline.objects.all().delete()
    crawler_settings = Settings()

    setup()
    configure_logging()
    crawler_settings.setmodule(my_settings)
    runner= CrawlerRunner(settings=crawler_settings)
    d=runner.crawl(news_spider.NewsSpider)
    time.sleep(3)
    # d=runner.crawl(news_spider.TechSpider)
    # time.sleep(3)
    return redirect("../getnews/")

@csrf_exempt
@require_http_methods(['POST', 'GET'])
def scrape1(request):
    EHeadline.objects.all().delete()
    crawler_settings = Settings()

    setup()
    configure_logging()
    crawler_settings.setmodule(economy_settings)
    runner= CrawlerRunner(settings=crawler_settings)
    d=runner.crawl(economy_spider.EconomySpider)
    time.sleep(3)
    d=runner.crawl(economy_spider.ExpressSpider)
    time.sleep(3)
    return redirect("../geteconomynews/")


@csrf_exempt
@require_http_methods(['POST', 'GET'])
def scrape2(request):
    SHeadline.objects.all().delete()
    crawler_settings = Settings()

    setup()
    configure_logging()
    crawler_settings.setmodule(sports_settings)
    runner= CrawlerRunner(settings=crawler_settings)
    d=runner.crawl(sports_spider.SportsSpider)
    time.sleep(3)
    d=runner.crawl(sports_spider.HtimesSpider)
    time.sleep(3)
    return redirect("../getsportsnews/")


@csrf_exempt
@require_http_methods(['POST', 'GET'])
def scrape3(request):
    PHeadline.objects.all().delete()
    crawler_settings = Settings()

    setup()
    configure_logging()
    crawler_settings.setmodule(politics_settings)
    runner= CrawlerRunner(settings=crawler_settings)
    d=runner.crawl(politics_spider.PoliticsSpider)
    time.sleep(3)
    d=runner.crawl(politics_spider.EconomicSpider)
    time.sleep(3)
    return redirect("../getpoliticsnews/")


@csrf_exempt
@require_http_methods(['POST', 'GET'])
def scrape4(request):
    LHeadline.objects.all().delete()
    crawler_settings = Settings()

    setup()
    configure_logging()
    crawler_settings.setmodule(lifestyle_settings)
    runner= CrawlerRunner(settings=crawler_settings)
    d=runner.crawl(lifestyle_spider.LifestyleSpider)
    time.sleep(3)
    d=runner.crawl(lifestyle_spider.HealthSpider)
    time.sleep(3)
    return redirect("../getlifestylenews/")


@csrf_exempt
@require_http_methods(['POST', 'GET'])
def scrape5(request):
    ENHeadline.objects.all().delete()
    crawler_settings = Settings()

    setup()
    configure_logging()
    crawler_settings.setmodule(entertainment_settings)
    runner= CrawlerRunner(settings=crawler_settings)
    d=runner.crawl(entertainment_spider.EntertainmentSpider)
    time.sleep(3)
    d=runner.crawl(entertainment_spider.EntrtnmentSpider)
    time.sleep(3)
    return redirect("../getentertainmentnews/")

# @csrf_exempt
# @require_http_methods(['POST', 'GET'])
# def scrapeAuto(request):
#     AHeadline.objects.all().delete()
#     crawler_settings = Settings()

#     setup()
#     configure_logging()
#     crawler_settings.setmodule(autoscraper_settings)
#     runner = CrawlerRunner(settings=crawler_settings)
#     time.sleep(3)
#     d=runner.crawl(auto_crawl.autoscrape)
#     time.sleep(3)
#     return redirect("../getcrawlednews/")

from rest_framework import viewsets
from .serializers import SaveArticleSerializer



class SaveArticleViewSet(viewsets.ModelViewSet):
    queryset = Headline.objects.all()
    serializer_class = SaveArticleSerializer

    def list(self, request):
        queryset = self.get_queryset()
        serializer = SaveArticleSerializer(queryset, many=True)
        return Response(serializer.data)
    
from rest_framework.renderers import JSONRenderer
import json

@csrf_exempt
@require_http_methods(['POST', 'GET'])
def formSend(request):
    if request.method == 'POST':
        entered_url = request.POST['url']
        class_name = request.POST['class_name']
        print(entered_url)
        print(class_name)
        Headline.objects.all().delete()
        crawler_settings = Settings()

        setup()
        configure_logging()
        crawler_settings.setmodule(my_settings)
        # runner= CrawlerRunner(settings=crawler_settings)
        # news_spider.NewsSpider(entered_url)
        # d=runner.crawl(news_spider.NewsSpider)
        process = CrawlerProcess(settings=crawler_settings)
        d = process.crawl(news_spider.NewsSpider, start_url = entered_url, class_name = class_name)
        time.sleep(3)
        # d=runner.crawl(news_spider.TechSpider)
        # time.sleep(3)
        # c = SaveArticleViewSet()
        # c.list(request)
        my_objects = Headline.objects.all()
        serializer = SaveArticleSerializer(my_objects, many=True)
        serialized_data = serializer.data
        json_data = json.dumps(serialized_data)
        return JsonResponse(json_data, safe=False)
        # return redirect("/api/")
    return render(request, "news/form.html")


# from django.shortcuts import render
# from .models import RSSFeed

# def rss_feed(request, id):
#     feed = RSSFeed.objects.get(id=id)
#     feed_link = feed.get_feed_link()
#     return render(request, 'rss_feed.html', {'feed_link': feed_link})

# scrape_no = 0

from django.contrib.syndication.views import Feed
from django.urls import reverse
from news.models import RSSFeed, ShiftArticles

# from django.utils.feedgenerator import Rss201rev2Feed

class MyFeed(Feed):
    title = "My Feed"
    link = "/"
    description = "My feed description"
    scrape_no = 0
    feed_url = ""


    def __init__(self, scrape_no = 0, feed_url = ""):
        super(Feed, self).__init__()
        self.scrape_no = scrape_no
        MyFeed.scrape_no = self.scrape_no
        # self.feed_url = feed_url

    # def __init__(self, dummy_id):
    #     self.dummy_id = dummy_id

    # def __init__(request, scrape_no):
    #     MyFeed.scrape_no = scrape_no

    def items(self):
        return ShiftArticles.objects.filter(scrape_no = MyFeed.scrape_no)

    def item_title(self, item):
        return item.title

    def item_description(self, item):
        return item.description

    def item_link(self, item):
        return item.url

    # def item_pubdate(self, item):
    #     return item.date_time
    def item_link(self, item):
        url = '/rss/' + str(item.scrape_no)
        rss_feed = SaveUrl(url=url)
        rss_feed.save()
        return url
    
    def get_feed(self, obj, request):
        feed = super().get_feed(obj, request)
        feed.feed['link'] = self.feed_url
        return feed

from django.views.decorators.http import require_GET


# @csrf_exempt
# @require_http_methods(['POST', 'GET'])
# def shift_data(request):
#     if request.method == "POST":
#         scrape_obj = SaveArticles.objects.last()
#         scrape_no = scrape_obj.scrape_no
#         scrape_no += 1
#         Headline_objs = Headline.objects.all()
#         for obj in Headline_objs:
#             SaveFeed_obj = SaveArticles(title = obj.title, image = obj.image, url = obj.url, source = obj.url, date_time = obj.date_time, description = obj.description, scrape_no = scrape_no)
#             SaveFeed_obj.save()
#         Headline.objects.all().delete()
#         feedClass = MyFeed(scrape_no)
#         # feedClass.items()
#         # feedClass.__call__(request)
#         # return redirect(f'/rss/{scrape_no}/')
#         with open('latest_posts.xml', 'w') as f:
#             f.write(str(feedClass))

#     # Return the RSS feed as an HTTP response
#         with open('latest_posts.xml', 'r') as f:
#             response = HttpResponse(f.read(), content_type='application/rss+xml')
#             response['Content-Disposition'] = 'attachment; filename="latest_posts.xml"'
#             return response
#     return HttpResponse("OK!")

@csrf_exempt
@require_http_methods(['POST', 'GET'])
def shift_data(request):
    if request.method == "POST":
        scrape_obj = ShiftArticles.objects.last()
        scrape_no = scrape_obj.scrape_no
        scrape_no += 1
        Headline_objs = Headline.objects.all()
        for obj in Headline_objs:
            SaveFeed_obj = ShiftArticles(title = obj.title, image = obj.image, url = obj.url, source = obj.url, date_time = obj.date_time, description = obj.description, scrape_no = scrape_no)
            SaveFeed_obj.save()
        Headline.objects.all().delete()
        feedClass = MyFeed(scrape_no, feed_url = request.build_absolute_uri())
        feedClass.items()
        feedClass.title = f"My feed {scrape_no}"
        feedClass.description = "This is a MWFeeds generated RSS feed"
        feedClass.link = "/"
        feedClass.feed_url = request.build_absolute_uri()
        # feed = feedClass.__call__(request, scrape_no = scrape_no)
        # response = HttpResponse(content_type='application/rss+xml')
        # response.write(feed)
        # response['Content-Disposition'] = ' attachment; filename="latest_posts.xml" '
        # return response
        RSSFeed(Feed_Title = feedClass.title, Created_By = "MWFeeds").save()
        with open('latest_posts.xml', 'w', encoding='utf-8') as f:
            f.write(feedClass.__call__(request, scrape_no).content.decode('utf-8'))
        with open('latest_posts.xml', 'r') as f:
            response = HttpResponse(f.read(), content_type='application/rss+xml')
            response['Content-Disposition'] = 'attachment; filename="latest_posts.xml"'
            return response
    return HttpResponse("OK!")


# dummy_id = 1

# def rss_feed(request, dummy_id):
#     rss = MyFeed(dummy_id)
#     url = request.absolute_uri(reverse('rss_feed', args = [dummy_id]))
#     SaveUrl(url).save()
#     return HttpResponse(rss, content_Type = 'application/rss+xml')

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from news import serializers


# class HelloApiView(APIView):
#     serializer_class = serializers.ArticleSerializer
#     """Test API view"""

#     def get(self, request, format=None):
#         an_apiview = [
#             'Uses HTTP methods',
#             'Is similar to a traditional Django View',
#             'Gives you the most control over application logic',
#             'Is mapped manually to URLs'
#         ]

#         return Response({'message': 'Hello!', 'an_apiview': an_apiview})
    
#     def post(self, request):
#         serializer = self.serializer_class(data=request.data)

#         if serializer.is_valid():
#             name = serializer.validated_data.get('id')


import os
from django.conf import settings
from django.http import HttpResponse
from django.shortcuts import render
from news.models import RssFeedModel
import feedparser
import codecs


from django.http import HttpResponsePermanentRedirect
from django.shortcuts import get_object_or_404

def view_rss_feed(request, rss_feed_id):
    rss_feed = get_object_or_404(RssFeedModel, pk=rss_feed_id)
    return HttpResponsePermanentRedirect(rss_feed.url)


import json
import xml.etree.ElementTree as ET

@csrf_exempt
@require_http_methods(['POST', 'GET'])
def rss_feed_view(request):
    if request.method == 'POST':
        feedurl = request.POST['feedurl']
        feed = feedparser.parse(feedurl)
        json_feed = json.dumps(feed)
        utf8_feed = codecs.encode(json_feed, 'utf-8')
            # Do something with the UTF-8 encoded feed
        # feed_tree = ET.ElementTree(ET.fromstring(utf8_feed))
        # pretty_feed = ET.tostring(feed_tree.getroot(), encoding='unicode', method='xml')

        # response = HttpResponse(pretty_feed, content_type='application/rss+xml; charset=utf-8')
        # return response
        response = HttpResponse(utf8_feed, content_type='application/rss+xml; charset=utf-8')
        return response
    return render(request, 'news/utf8.html')



import datetime
import builtins
import feedparser
import xml.etree.ElementTree as ET
# from datetime import datetime as dt

def filtered_feed(request):
    if request.method == 'POST':
        feed_url = request.POST['feed_url']
        now = datetime.datetime.now(datetime.timezone.utc)
        feed = feedparser.parse(feed_url)

    # Create an Element object representing the root element of an RSS feed
        rss = ET.Element('rss', {'version': '2.0'})
        channel = ET.SubElement(rss, 'channel')

        # Add the required elements to the channel element
        title = ET.SubElement(channel, 'title')
        title.text = feed.feed.title
        link = ET.SubElement(channel, 'link')
        link.text = feed.feed.link
        description = ET.SubElement(channel, 'description')
        description.text = feed.feed.description

        # Loop through the items in the feed and add any with a past or current date to the channel
        for item in feed.entries:
            # Get the date of the item
            item_date = datetime.datetime.strptime(item.published, '%Y-%m-%dT%H:%M:%S%z')
            # Compare the item date to the current date and time
            if item_date <= now:
                # Create an item element and add the required elements to it
                item_elem = ET.SubElement(channel, 'item')
                title = ET.SubElement(item_elem, 'title')
                title.text = item.title
                link = ET.SubElement(item_elem, 'link')
                link.text = item.link
                description = ET.SubElement(item_elem, 'description')
                description.text = item.description
                pub_date = ET.SubElement(item_elem, 'pubDate')
                pub_date.text = item.published

        # Convert the Element object to an XML string
        xml_string = ET.tostring(rss, encoding='utf-8')

        # Return the updated feed as an HTTP response
        return HttpResponse(xml_string, content_type="application/rss+xml")
    return render(request, 'news/futdate.html')