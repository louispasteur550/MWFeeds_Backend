# from django.db import models
from djongo import models

import uuid
from django.core.validators import RegexValidator


class Headline(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=200)
    image = models.URLField(null = True, blank = True)
    url = models.URLField()
    source = models.CharField(max_length=200,null = True,blank=True)
    date_time = models.CharField(max_length=100, null= True, blank=True)
    description = models.CharField(max_length=200, null=True, blank=True)

    def __str__(self):
        return self.title
    
# class RSSFeed(models.Model):
#     id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
#     title = models.CharField(max_length=255)
#     url = models.URLField()
#     source = models.CharField(max_length=200,null = True,blank=True)
#     date_time = models.CharField(max_length=100, null= True, blank=True)
#     description = models.CharField(max_length=200, null=True, blank=True)
#     def get_feed_link(self):
#         base_url = "https://example.com/feed"
#         feed_title = self.title
#         feed_url = self.url
#         uuid_str = str(self.id)
#         return f"{base_url}?id={uuid_str}&title={feed_title}&url={feed_url}"

class EHeadline(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=200)
    image = models.URLField(null = True, blank = True)
    url = models.TextField()
    source = models.CharField(max_length=200,null = True,blank=True)

    def __str__(self):
        return self.title

class SHeadline(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=200)
    image = models.URLField(null = True, blank = True)
    url = models.TextField()
    source = models.CharField(max_length=200,null = True,blank=True)

    def __str__(self):
        return self.title

class PHeadline(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=200)
    image = models.URLField(null = True, blank = True)
    url = models.TextField()
    source = models.CharField(max_length=200,null = True,blank=True)

    def __str__(self):
        return self.title

class LHeadline(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=200)
    image = models.URLField(null = True, blank = True)
    url = models.TextField()
    source = models.CharField(max_length=200,null = True,blank=True)

    def __str__(self):
        return self.title

class ENHeadline(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=200)
    image = models.URLField(null = True, blank = True)
    url = models.TextField()
    source = models.CharField(max_length=200,null = True,blank=True)

    def __str__(self):
        return self.title
    
# class AHeadline(models.Model):
#     title = models.CharField(max_length=200)
#     image = models.URLField(null = True, blank = True)
#     url = models.TextField()
#     source = models.CharField(max_length=200,null = True,blank=True)

#     def __str__(self):
#         return self.title


# class SaveArticles(models.Model):
#     scrape_no = models.IntegerField()
#     title = models.CharField(max_length=200)
#     image = models.URLField(null=True, blank=True)
#     url = models.URLField()
#     source = models.CharField(max_length=200, null=True, blank=True)
#     date_time = models.CharField(max_length=100, null=True, blank=True)
#     description = models.CharField(max_length=200, null=True, blank=True)

class ShiftArticles(models.Model):
    scrape_no = models.IntegerField()
    title = models.CharField(max_length=200)
    image = models.URLField(null=True, blank=True)
    url = models.URLField()
    source = models.CharField(max_length=200, null=True, blank=True)
    date_time = models.CharField(max_length=100, null=True, blank=True)
    description = models.CharField(max_length=200, null=True, blank=True)

import string, random

def generate_unique_id(): #function to create a unique 16 char ID
    length = 16

    while True:
        code = ''.join(random.choices(string.ascii_uppercase + string.digits +string.ascii_lowercase, k=length))
        if RSSFeed.objects.filter(UniqueID=code).count() == 0:
            break
    return code


class RSSFeed(models.Model):
    UniqueID = models.CharField(max_length=16, default = generate_unique_id, validators=[RegexValidator('^[a-zA-Z0-9]*$')], primary_key=True)
    Feed_Title = models.CharField(max_length=50, null = False)
    Date_Created = models.DateTimeField(editable=False, auto_now_add=True)
    Date_Modified = models.DateTimeField(auto_now=True)
    Created_By = models.CharField(max_length=40)

class SaveUrl(models.Model):
    id = models.AutoField(primary_key=True)
    url = models.URLField(null = True)


class RssFeedModel(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField()
    url = models.CharField(max_length=200, blank=True)

    def __str__(self):
        return self.title
    

class Dummy(models.Model):
    link = models.URLField(unique=True)