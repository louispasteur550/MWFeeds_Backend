from rest_framework import serializers
from .models import Headline

# class ArticleSerializer(serializers.Serializer):
#     id =serializers.CharField(max_length=10)
#     title = serializers.CharField(max_length=200)
#     image = serializers.URLField(null = True, blank = True)
#     url = serializers.URLField()
#     source = serializers.CharField(max_length=200,null = True,blank=True)
#     date_time = serializers.CharField(max_length=100, null= True, blank=True)
#     description = serializers.CharField(max_length=200, null=True, blank=True)

class SaveArticleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Headline
        fields = '__all__'