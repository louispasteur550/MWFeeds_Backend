from django.urls import path, include
from .views import NewsListView,SportsListView,EconomyListView,PoliticsListView,LifestyleListView,EntertainmentListView, MyFeed
from . import views

from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register('article-viewset', views.SaveArticleViewSet, basename='article-viewset')

urlpatterns = [
	path('scrape/', views.scrape, name="scrape"),
	path('scrape1/', views.scrape1, name="scrape1"),
	path('scrape2/', views.scrape2, name="scrape2"),
	path('scrape3/', views.scrape3, name="scrape3"),
	path('scrape4/', views.scrape4, name="scrape4"),
	path('scrape5/', views.scrape5, name="scrape5"),
	path('getnews/', NewsListView.as_view(), name='home'),
	path('geteconomynews/', EconomyListView.as_view(), name='economy_home'),
	path('getsportsnews/', SportsListView.as_view(), name='sports_home'),
	path('getpoliticsnews/', PoliticsListView.as_view(), name='politics_home'),
	path('getlifestylenews/', LifestyleListView.as_view(), name='lifestyle_home'),
	path('getentertainmentnews/', EntertainmentListView.as_view(), name='entertainment_home'),
	path('menu/', views.menu_list, name='menu'),
	path('', views.home1, name="starter"),
    path('form', views.formSend),
    path('shift_data/', views.shift_data, name='shift_data'),
    # path('feed/', MyFeed(), name='feed'),
    path('api/', include(router.urls)),
    # path('rss/<int:dummy_id>/', views.rss_feed, name='rss_feed'),
	# path('rss/<int:scrape_no>/', MyFeed(), name='rss_feed'),
    path('utf8/', views.rss_feed_view, name="rss_feed_view"),
    path('filtered_feed/', views.filtered_feed, name='filtered_feed'),
]